import pyscamp as mp # Uses GPU if available and CUDA was available during the build
import numpy as np
import os
import sys
import math

import matplotlib.pyplot as plt

def get_train_size_from_filename(filename):
    return int(filename.split('_')[-1].split('.')[0])

def detect1_2(ts, win_size):
    profile, index = mp.selfjoin(ts, win_size)
    max_index = np.argmax(profile)
    return profile[max_index], max_index

def detect2_2(ts, query, win_size):
    profile, index = mp.abjoin(ts, query, win_size)
    print(len(profile), profile)
    max_index = np.argmax(profile)
    return profile[max_index], max_index

def read_win_size_array(fn):
    ret = [-1]
    for line in open(fn):
        file_no, win_size, _ = line.strip().split(",")
        ret.append(int(win_size))
    return ret

if __name__ == '__main__':
    sample_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../samples"))
    result_file_name_prefix = sys.argv[0].split(".")[0]
    start_file_no = int(sys.argv[1])
    winsize_file_name = sys.argv[2]

    win_size_array = read_win_size_array(winsize_file_name)

    print(win_size_array)

    of = open(result_file_name_prefix+".csv", "a+")
    of.write("No.,location\n")

    for sample_file in os.listdir(sample_dir):
        file_no = int(sample_file.split("_")[0])
        if file_no < start_file_no:
            continue
        #if file_no > 25:
        #    break

        train_size = get_train_size_from_filename(sample_file)

        train = []
        test = []
        for idx, line in enumerate(open(os.path.join(sample_dir, sample_file))):
            if idx < train_size:
                train.append(float(line.strip()))
            else:
                test.append(float(line.strip()))

        outlier_pos = 0
        if file_no in [239,240,241]:
            outlier_pos = 0 + train_size #give up large samples
        else:
            win_size = win_size_array[file_no]
            p, outlier_pos = detect2_2(test, train, win_size)
            outlier_pos += train_size
            if (win_size > 100):
                outlier_pos += win_size/2

        of.write(f"{file_no},{outlier_pos}\n")
        of.flush()

    of.close()