import pyscamp as mp # Uses GPU if available and CUDA was available during the build
import numpy as np
import os
import sys
import math

import matplotlib.pyplot as plt

from base import *

class Tsctl:
    def __init__(self, file_no, mp_win_size, hardcore, method_name):
        self.file_no = int(file_no)
        self.mp_win_size = int(mp_win_size)
        self.hardcore = hardcore
        self.method_name = method_name
        if (self.method_name == ''):
            self.method_name = "matrixprofile"

        if (self.method_name not in ["matrixprofile", "lu"]):
            raise ValueError(f"unsupported method: {self.method_name}")

def read_tsctl_array(fn):
    ret = [None]
    for line in open(fn):
        file_no, mp_win_size, hardcore, method_name = line.strip().split(",")
        ret.append(Tsctl(file_no, mp_win_size, hardcore, method_name))
    return ret

if __name__ == '__main__':
    sample_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../samples"))
    result_file_name_prefix = sys.argv[0].split(".")[0]
    start_file_no = int(sys.argv[1])
    ctl_file_name = sys.argv[2]

    tsctl_array = read_tsctl_array(ctl_file_name)

    of = open(result_file_name_prefix+".csv", "a+")
    of.write("No.,location\n")

    for sample_file in os.listdir(sample_dir):
        file_no = int(sample_file.split("_")[0])
        if file_no < start_file_no:
            continue
        #if file_no > 25:
        #    break

        train_size = get_train_size_from_filename(sample_file)

        train, test = read_train_test(os.path.join(sample_dir, sample_file), train_size)

        outlier_pos = 0
        if file_no in [239,240,241]:
            outlier_pos = 0 #give up large samples
        else:
            tsctl = tsctl_array[file_no]
            if tsctl.method_name == 'matrixprofile':
                win_size = tsctl.mp_win_size
                p, outlier_pos, p_l = mp_detect_abjoin(test, train, win_size)
                if (win_size > 100):
                    outlier_pos += int(win_size/2)
            elif tsctl.method_name == 'lu':
                anomaly_score_l = luminol_detect(test)
                outlier_pos = np.argmax(anomaly_score_l)

        outlier_pos += train_size

        print(f"{file_no},{outlier_pos}")

        of.write(f"{file_no},{outlier_pos}\n")
        of.flush()

    of.close()